<!-- Footer -->
<footer class="page-footer font-small blue pt-4">

  <!-- Footer Links -->

  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2021 Patel Ayush:
    <a href=" "> Lraravel Crud </a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
<?php /**PATH C:\xampp\htdocs\lara\lcrud\lblog\resources\views/layouts/footer.blade.php ENDPATH**/ ?>